# Boussoles SCANOPTIMUS9 (Streamlit)

## Lancer sur ton ordinateur
1. Installer Python 3.10 ou plus récent.
2. Dans ce dossier : `pip install -r requirements.txt`
3. `streamlit run app.py` : la page s'ouvre dans le navigateur.

- Les cours, taux, dollar, VIX et positions des spéculateurs se téléchargent à l'ouverture, puis sont gardés 6 heures. Le bouton « Mettre à jour les données » force un nouveau téléchargement.
- Si une source ne répond pas, l'application reprend la dernière copie de `cache/` (pastille 🟡).
- **Fichiers qui périment** (compositions, membres du NDX, 13F, crédit sur marge) : tous dans `fichiers/`, mis à jour par `python fichiers/mettre_a_jour.py`. Voir `fichiers/NOTICE.md`.

## Comment lire l'outil
**Règle d'or :** la position vient des règles. Les lois et les alertes éclairent, elles ne décident pas. Si une alerte contredit la règle, la règle gagne.

| Onglet | Ce qu'il dit |
|---|---|
| Vue d'ensemble | Conclusion du jour (position et poids de chaque part, ce qui changerait la décision, alertes du décor), climat du mini-cycle (VIX, dollar), une carte par marché |
| Marchés | Un marché à la fois : badge = position selon la règle ; tuiles cycle, mini-cycle, S5 et carte des prix ; graphique ; lecture par les lois ; titres. « Or & mines » : décision, titres, matière première, repères GDX |
| Macro | Interrupteur, VIX, taux, dollar, crédit sur marge, institutions 13F, concentration, sur un même axe de temps |
| Interroger l'historique | Ce qui s'est passé après chaque signal passé |

**Les familles d'indicateurs** (familles_indicateurs) :
- **A, cycle :** si l'on peut être investi (stratégie A, S7, interrupteur coût du capital).
- **B, mini-cycle :** quand et quoi détenir (S5, couteau, G3 « hausse effacée », poids).
- **C, tension de fin de cycle :** alertes (interrupteur armé, taux réel, crédit sur marge, 13F, concentration, dispersion).
- **D, climat de creux :** alertes (correction généralisée, peur VIX).

## Le système (journal de décisions)
| Brique | Règle |
|---|---|
| Univers | SOX, logiciel (IGV), NDX en titres ; or à part ; pétrole non timable ; S&P 500 affiché, non tradé |
| Position par part | Cycle ouvert → cœur de 2 titres, figé au dernier S5 (cœur permanent, 19/11/2026) ; cycle fermé, interrupteur actif ou hausse effacée (G3) → cash |
| Exécution | À la clôture du jour du signal (ordre au cours de clôture). Les sorties sont des niveaux connus la veille |
| Or | Stratégie décor + amorce. Part de mines = budget de risque (cœur de 2 mines), le reste en PHYS |
| Poids | W1 en fin de mois (inverse de la volatilité, cash compris, plancher 5 %) × l'état du cycle de la part : cycle porteur × 1,5, couteau pris par un S5 × 0,5, fin de cycle proche × 0,5 ; total investi ≤ 100 %, 50 % au plus par part, 25 % pour l'or tant qu'il n'a pas de trades réels, le reste en cash |
| **Break (il l'emporte sur tout)** | Capital à −30 % de son plus haut → tout couper ; retour au plus tôt 3 mois après, quand le S&P a clôturé deux fins de mois au-dessus de sa moyenne 10 mois. Blocage K2 (S&P sous sa moyenne 10 mois en clôture mensuelle et décor de taux allumé) → aucune entrée nouvelle, levé après deux fins de mois au-dessus. −35 % → arrêt du système (break) |
| Résultat testé | Simulation 2016-2026 : +39,7 %/an, pire baisse −23 % ; 2022-2026 : +61,7 %/an, −16 % (dans l'échantillon). Espérance réaliste ≈ +20 %/an, −30 %, si le régime haussier dure ; hors échantillon 1995-2015 (indices) : +3,6 %/an, −82 % |

## Barre latérale
- **Séance analysée :** rejoue n'importe quelle séance passée, avec les seules données connues ce jour-là.
- **Comparer avec une autre séance :** affiche les écarts (⇄).
- **Mémoire des statistiques :** les 4 dernières années (par défaut) ou tout l'historique.
- **Mon capital :** plus haut atteint et valeur du jour, pour le break à −30 %. Gardés dans `fichiers/capital.json`, sur ton ordinateur seulement.
- **Péremption :** date limite de chaque réglage et de chaque fichier.

## Organisation du code
| Fichier | Contenu |
|---|---|
| `boussoles/regles.py` | Seuils, lois, péremptions, décisions du trader. On n'y touche qu'après un nouveau test |
| `boussoles/donnees.py` | Téléchargements et copie de secours |
| `boussoles/calcul.py` | Cycles, S7, stratégie A, S5, P4, lois du jour, climat, or |
| `boussoles/titres.py` | Choix des titres, cœur, G3, portefeuille et poids |
| `boussoles/ui.py` | Cartes, jauges, pastilles |
| `fichiers/` | Fichiers à mettre à jour, notice et script de mise à jour |

---
# Annexe · historique des versions

## v6.6 (19/11/2026)
- Cœur permanent : la liste des 5 n'est plus détenue ; un couteau touché en cycle ouvert garde le cœur (coeur_permanent). Exécution à la clôture du jour du signal (timing_entree).
- « Ce que vaut le système » : espérance et scénario 2000-2009 en premier, résultats avec leurs dates exactes (dossier sectoriel du 19/11).
- Break du trader en tête de la Conclusion du jour : distance du capital aux −30 %, blocage K2, S&P contre sa moyenne 10 mois, décor de taux (break, simplification).
- Saisie du capital dans la barre latérale.
- Part or limitée à 25 % (limite_or : coût −2,6 pts/an sur 2016-2026).

## v6.5 (19/11/2026)
- Conclusion du jour en fin de vue d'ensemble, présentation revue : 4 chiffres clés, tableau des positions (statut, titres, poids avec jauge et état du cycle, prochain déclencheur), alertes en étiquettes, légende repliable.
- « Prochain déclencheur » corrigé quand un S5 est en cours alors que le cycle est fermé (couteau → cash).
- Onglet Or & mines : les repères GDX passent juste avant les signaux d'entrée.

## v6.4 (18/11/2026) · dernière passe
- Vitrine : espérance réaliste et résultat hors échantillon affichés à côté de la simulation.
- Historique des titres porté à 10 ans (rejouer une séance jusqu'à 2019 ; avant, la Conclusion du jour est indisponible faute de titres).
- Documentation complète : DOSSIER_APPLICATION.md (reconstruire le système et l'application de A à Z).

## v6.3 (18/11/2026)
- Plafond au poids actif retiré ; limite de prudence de 50 % du capital par part (décision du trader, posée après le test).

## v6.2 (18/11/2026)
- Poids dynamiques (P4) retirés (décision du trader). Ils sont remplacés par l'allocation selon l'état du cycle (allocation_cycles), avec un plafond au poids actif.
- Or : budget mines + PHYS confirmé.
- Onglet Pétrolières : repère « Régime du pétrole · accélération » (petrole_acceleration). Le pétrole reste non timable.

## v6.1 (18/11/2026) · revue de cohérence
- Badge des marchés = position selon la règle (CŒUR, LISTE DES 5, CASH, CASH · PIC, S5 EN COURS, CYCLE FERMÉ, REPÈRE, NON TIMABLE). Il ne reprend plus « la loi la plus sévère ».
- Poids dynamiques (poids_dynamique, P4) : W1 plafonné au poids actif du secteur, × 0,5 si le secteur perd de la vitesse. Une part dehors affiche son poids « si entrée ».
- Or : part de mines = budget de risque, le reste en PHYS (or_phys).
- Vue d'ensemble allégée : la Conclusion du jour remplace « Signaux du jour », le bloc Or et « Portefeuille du jour ». Le climat garde le VIX et le dollar.
- Une seule définition de la concentration (≥ 5 pts dans les 60 dernières séances).
- Textes corrigés : loi de l'interrupteur (volet Fed), doublon retiré, chiffres de l'or et de la vitrine mis à jour, repères GDX sans cycle A.
- Pétrole (petrole_2022) : toujours non timable sur 2022-2026.

## Titres de chaque thématique (v5, 17/11/2026)
- Sous l'analyse de SOX, Logiciel et NDX, l'application affiche :
  - la position en titres : cœur, liste des 5, cash ou à l'abri ;
  - les 5 titres choisis et le cœur ;
  - pour chaque titre : son bêta en correction, sa performance depuis le S5 et sa moyenne 50.
- Fichier à rafraîchir chaque trimestre : `fichiers/compositions_actuelles.csv` (poids de SOXX et IGV). Pour le NDX, les membres sont dans `fichiers/ndx_membres.csv` et le classement se fait par volume en dollars.

## Or en titres et péremption (v5.1, 17/11/2026)
- Onglet « Or · stratégie » : cœur de 2 mines (parmi les 15 plus gros poids de GDX, les 2 au bêta en correction le plus élevé), détenu quand la stratégie or est investie (choix du trader, or_sans_etf).
- Barre latérale « Péremption » : réglages et fichiers, avec 🟢, 🟡 (30 jours) ou 🔴 (expiré), et une alerte en haut de page si une date est dépassée.
- La composition GDX vient de la dernière déclaration SEC (telecharger_y4_or.py).

## Décisions de cycle et recalibrage (v5.3, 17/11/2026)
- `regles.DECISIONS_CYCLE` : une fin de cycle déclarée par le trader force la sortie de la stratégie A ce jour-là, et l'onglet l'affiche (« fermé · décision du trader »). Aujourd'hui : SOX au 16/11/2026.
- Barre latérale : « Recalibrage requis · marché » dès qu'un marché sort de son cycle après `DATE_CALIBRAGE`.

## Portefeuille du jour (v5.5, 18/11/2026 : défensif hors stratégie, poids en fin de mois)
- **Vue d'ensemble, section « Portefeuille du jour » :**
  - pour chaque part : son poids, son état et ce qu'il faut détenir ;
  - la part du capital en défensif (5 plus gros poids de XLP) ;
  - deux alertes : « Correction généralisée · tech » et « Dispersion des secteurs tech ».
- **Calcul des poids :** inverse de la volatilité sur 63 séances de ce que chaque part a détenu (l'indice si investie, XLP sinon).
- **Composition XLP** (déclaration SEC) dans compositions_actuelles.csv. Péremption : 6 mois, comme pour GDX.
- **v5.5 :**
  - une part dehors est en cash ;
  - poids : inverse de la volatilité de chaque part sur 63 séances, cash compris (plancher 5 %), revus à la dernière fin de mois ;
  - XLP n'est plus qu'une poche affichée, hors stratégie.

## Sortie de pic « hausse effacée » (v5.6, 18/11/2026)
- **Règle :** dans les 3 séances qui suivent un plus haut de 10 séances, si la clôture repasse sous la plus basse clôture des 10 séances d'avant, la part passe en « CASH · PIC ».
- **Retour en position :** à une clôture au-dessus du plus haut de 10 séances qui précédait le signal, ou au prochain S5.
- **Source :** pic_distribution.

## Alerte crédit sur marge (v5.7, 18/11/2026)
- **Tuile « Crédit sur marge »** dans la vue d'ensemble, et carte d'alerte sur les marchés tech.
- **Source :** dette sur marge FINRA, téléchargée à chaque lancement. Une copie de secours, `fichiers/margin-statistics.xlsx`, est livrée avec l'application.
- **Délai :** un mois n'est utilisé qu'à partir du 25 du mois suivant.
- **Alerte :** elle s'allume quand la croissance sur 12 mois recule de 20 points ou plus depuis son plus haut de 6 mois, avec le NDX à moins de 5 % de son plus haut d'un an. C'est une lecture, pas une règle (dette_marge).
- **Nouvelle dépendance :** openpyxl (`pip install openpyxl`).

## Matières premières et onglet Macro (v5.8, 18/11/2026)
- **Matières premières :**
  - Mines d'or et Or · stratégie : cours de l'or (GC=F) ;
  - Pétrolières : cours du Brent (BZ=F) ;
  - chaque bloc montre le cours avec ses moyennes 50 et 200, son plus haut et son plus bas d'un an, et le secteur rapporté à la matière première ;
  - choix de la période : 6 mois, 1 an, 3 ans ou 10 ans.
- **Nouvel onglet « Macro » :** un graphique à panneaux sur un même axe de temps, avec les seuils et une légende :
  1. le NDX, avec les zones de l'interrupteur actif et de l'alerte crédit ;
  2. le VIX et son 80e percentile ;
  3. le coût du capital (10 ans et Fed) ;
  4. le taux réel et le dollar ;
  5. le crédit sur marge ;
  6. la concentration.

## Onglet « Or & mines » et alerte 13F (v5.9, 18/11/2026)
- **Un seul onglet pour l'or** (« Mines d'or » disparaît du sélecteur, qui garde 6 entrées) :
  1. décision : stratégie or, six conditions, graphique des signaux, puis les sorties ;
  2. titres : liste des 5 mines et cœur de 2 ;
  3. matière première : cours de l'or et rapport mines / or ;
  4. repères GDX (cycle, mini-cycle, S5, carte des prix) : lecture seule, sans verdict.
- **Onglet Macro :** nouvelle carte « Institutions · 13F » (13f.md). Elle s'allume si la dernière déclaration disponible montre des gérants qui vendent la tech pendant une hausse du NDX, ou une baisse active de 2 points ou plus.
  - Données : `fichiers/institutions_13f.csv` (23 gérants actifs, 2013-2026).
  - Péremption : 92 jours après la dernière publication. Mise à jour : `python fichiers/mettre_a_jour.py 13f` (v6.0).
- Légende du graphique des matières premières placée sous le graphique.

## Un seul dossier pour les mises à jour (v6.0, 18/11/2026)
- Tous les fichiers qui périment sont dans `fichiers/` : `ndx_membres.csv`, `compositions_actuelles.csv` (SOXX, IGV, GDX, XLP), `institutions_13f.csv`, `margin-statistics.xlsx`.
- Une seule commande les met à jour : `python fichiers/mettre_a_jour.py` (seulement ce qui périme ; `tout` pour forcer ; ou une étape : `ndx`, `ishares`, `sec`, `marge`, `13f`). Le 13F est recalculé sur ton ordinateur : plus besoin de m'envoyer les fichiers.
- Notice complète : `fichiers/NOTICE.md` (contenu, source, durée de vie, calendrier, que faire en cas d'erreur).
- Les anciens scripts `telecharger_*.py` ne servent plus pour l'outil (seulement pour refaire des tests historiques).
- **Conclusion du jour** (en tête de la vue d'ensemble) : une phrase et un tableau par part. Le tableau montre le cycle (famille A), le mini-cycle (B), la décision et les titres, le poids, et ce qui changerait la décision. Les alertes de tension de fin de cycle (C) et de climat de creux (D) sont affichées en pastilles. Elles éclairent sans décider (familles_indicateurs).
